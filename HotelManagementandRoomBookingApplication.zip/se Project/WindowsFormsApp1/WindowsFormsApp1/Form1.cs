﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.IO;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        string UserName = "";
        string Password = "";

        bool checkinfile(string UserName, string Password)
        {
            try
            {
                string[] lines = File.ReadAllLines("Login.txt");
                for (int i = 0; i < lines.Length; i += 3)
                {
                    string name = lines[i];
                    string Pass = lines[i + 1];

                    if (UserName == name && Password == Pass)
                    {
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            return false;
        }

        void saveinfile(string UserName, string Password)
        {
            File.AppendAllText("Login.txt", UserName + Environment.NewLine);
            File.AppendAllText("Login.txt", Password + Environment.NewLine);
            File.AppendAllText("Login.txt", "" + Environment.NewLine);
        }


        public Form1()
        {
            InitializeComponent();
        }


        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {
            splitContainer1.SplitterDistance = 960;
        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {
            splitContainer1.SplitterDistance = 960;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            maskedTextBox2.UseSystemPasswordChar = true;
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                maskedTextBox2.UseSystemPasswordChar = false;
            }
            else
            {
                maskedTextBox2.UseSystemPasswordChar = true;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            UserName = maskedTextBox1.Text;
            Password = maskedTextBox2.Text;
            if (checkinfile(UserName, Password))
            {
                Home_Page f = new Home_Page();
                f.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Please Signup");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserName = maskedTextBox1.Text;
            Password = maskedTextBox2.Text;
            if (checkinfile(UserName, Password))
            {
                MessageBox.Show("Please choose a different username or password as the one entered is already in use.");
            }
            else
            {
                if (UserName != "" && Password != "")
                {
                    saveinfile(UserName, Password);
                    Home_Page f = new Home_Page();
                    f.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Enter login details first");
                }

            }
        }

    }
}