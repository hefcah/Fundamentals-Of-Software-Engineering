﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.IO;
using static System.Windows.Forms.LinkLabel;

namespace WindowsFormsApp1
{

    public partial class ROOMS : Form
    {
        int update_booked_rooms(string type)
        {
            try
            {
                string file_name = "";
                if (type == "single:")
                {
                    file_name = "single_no_of_rooms.txt";
                }
                else if (type == "double:")
                {
                    file_name = "double_no_of_rooms.txt";
                }
                else
                {
                    file_name = "triple_no_of_rooms.txt";
                }

                string[] lines = File.ReadAllLines(file_name);
                int romm_num = 0;
                for (int i = 0; i < lines.Length; i++)
                {
                    char[] charArray = lines[i].ToCharArray();
                    for (int j = 0; j < charArray.Length; j++)
                    {
                        if (charArray[j] != ',')
                        {
                            romm_num++;
                        }
                        if (charArray[j] == '0')
                        {
                            charArray[j] = '1';
                            lines[i] = new string(charArray);
                            break;
                        }

                    }
                }
                File.WriteAllLines(file_name, lines);
                return romm_num;
            }
            catch (Exception)
            {
                Console.WriteLine("Error updating file");
            }
            return 0;

        }
        bool check_avalibility(string type)
        {
            try
            {
                string file_name = "";
                if (type == "single:")
                {
                    file_name = "single_no_of_rooms.txt";
                }
                else if (type == "double:")
                {
                    file_name = "double_no_of_rooms.txt";
                }
                else
                {
                    file_name = "triple_no_of_rooms.txt";
                }

                string[] lines = File.ReadAllLines(file_name);
                int j = 0;
                bool available = false;
                for (int i = 0; i < lines.Length; i++)
                {
                    if (lines[i].Contains("0"))
                    {
                        available = true;
                        break;
                    }
                }
                return available;
            }
            catch (Exception)
            {
                return false;
            }
            return false;
        }
        public ROOMS()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Home_Page f = new Home_Page();
            f.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ROOMS f = new ROOMS();
            f.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Food f = new Food();
            f.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            services_page f = new services_page();
            f.Show();
            this.Hide();
        }

        private void SingleBedroom_Click(object sender, EventArgs e)
        {
            if (check_avalibility("single:"))
            {
                Form2 f = new Form2(update_booked_rooms("single:"), "single");
                f.Show();
            }
            else
            {
                MessageBox.Show("No Single Bedroom Available");

            }
        }

        private void DoubleBedroom_Click(object sender, EventArgs e)
        {
            if (check_avalibility("double:"))
            {
                Form2 f = new Form2(update_booked_rooms("double:"), "double");
                f.Show();
            }
            else
            {
                MessageBox.Show("No Double Bedroom Available");

            }
        }

        private void CustomBedroom_Click(object sender, EventArgs e)
        {
            if (check_avalibility("custom:"))
            {
                Form2 f = new Form2(update_booked_rooms("custom:"), "triple");
                f.Show();
            }
            else
            {
                MessageBox.Show("No triple Bedroom Available");

            }
        }
    }
}
