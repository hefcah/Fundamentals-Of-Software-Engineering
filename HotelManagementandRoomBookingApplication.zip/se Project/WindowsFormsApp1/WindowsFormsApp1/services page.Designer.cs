﻿namespace WindowsFormsApp1
{
    partial class services_page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.Home = new System.Windows.Forms.Button();
            this.ContactUs = new System.Windows.Forms.Button();
            this.Services = new System.Windows.Forms.Button();
            this.Food = new System.Windows.Forms.Button();
            this.roooms = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.foood = new System.Windows.Forms.Button();
            this.CleaningServices = new System.Windows.Forms.Button();
            this.Laundry = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AccessibleRole = System.Windows.Forms.AccessibleRole.Application;
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.Home);
            this.panel1.Controls.Add(this.ContactUs);
            this.panel1.Controls.Add(this.Services);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.Food);
            this.panel1.Controls.Add(this.roooms);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(285, 1041);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Home
            // 
            this.Home.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Home.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Home.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Home.ForeColor = System.Drawing.SystemColors.Window;
            this.Home.Location = new System.Drawing.Point(46, 336);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(186, 86);
            this.Home.TabIndex = 6;
            this.Home.Text = "Home";
            this.Home.UseVisualStyleBackColor = false;
            this.Home.Click += new System.EventHandler(this.Home_Click);
            // 
            // ContactUs
            // 
            this.ContactUs.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ContactUs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ContactUs.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ContactUs.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ContactUs.ForeColor = System.Drawing.SystemColors.Window;
            this.ContactUs.Location = new System.Drawing.Point(46, 767);
            this.ContactUs.Name = "ContactUs";
            this.ContactUs.Size = new System.Drawing.Size(186, 86);
            this.ContactUs.TabIndex = 5;
            this.ContactUs.Text = "Contact Us";
            this.ContactUs.UseVisualStyleBackColor = false;
            this.ContactUs.Click += new System.EventHandler(this.ContactUs_Click);
            // 
            // Services
            // 
            this.Services.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Services.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Services.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Services.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Services.ForeColor = System.Drawing.SystemColors.Window;
            this.Services.Location = new System.Drawing.Point(46, 665);
            this.Services.Name = "Services";
            this.Services.Size = new System.Drawing.Size(186, 86);
            this.Services.TabIndex = 4;
            this.Services.Text = "Services";
            this.Services.UseVisualStyleBackColor = false;
            this.Services.Click += new System.EventHandler(this.Services_Click);
            // 
            // Food
            // 
            this.Food.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Food.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Food.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Food.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Food.ForeColor = System.Drawing.SystemColors.Window;
            this.Food.Location = new System.Drawing.Point(46, 560);
            this.Food.Name = "Food";
            this.Food.Size = new System.Drawing.Size(186, 86);
            this.Food.TabIndex = 3;
            this.Food.Text = "Food";
            this.Food.UseVisualStyleBackColor = false;
            this.Food.Click += new System.EventHandler(this.Food_Click);
            // 
            // roooms
            // 
            this.roooms.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.roooms.Cursor = System.Windows.Forms.Cursors.Hand;
            this.roooms.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.roooms.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roooms.ForeColor = System.Drawing.SystemColors.Window;
            this.roooms.Location = new System.Drawing.Point(46, 453);
            this.roooms.Name = "roooms";
            this.roooms.Size = new System.Drawing.Size(186, 86);
            this.roooms.TabIndex = 2;
            this.roooms.Text = "Rooms";
            this.roooms.UseVisualStyleBackColor = false;
            this.roooms.Click += new System.EventHandler(this.roooms_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button3.Font = new System.Drawing.Font("Microsoft YaHei UI", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(944, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(337, 55);
            this.button3.TabIndex = 11;
            this.button3.Text = "Services";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // foood
            // 
            this.foood.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.FOOOOF;
            this.foood.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.foood.Cursor = System.Windows.Forms.Cursors.Hand;
            this.foood.Location = new System.Drawing.Point(1316, 741);
            this.foood.Name = "foood";
            this.foood.Size = new System.Drawing.Size(500, 300);
            this.foood.TabIndex = 14;
            this.foood.UseVisualStyleBackColor = true;
            // 
            // CleaningServices
            // 
            this.CleaningServices.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.WhatsApp_Image_2023_09_20_at_23_56_55;
            this.CleaningServices.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CleaningServices.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CleaningServices.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.CleaningServices.Location = new System.Drawing.Point(822, 408);
            this.CleaningServices.Name = "CleaningServices";
            this.CleaningServices.Size = new System.Drawing.Size(500, 300);
            this.CleaningServices.TabIndex = 13;
            this.CleaningServices.UseVisualStyleBackColor = true;
            // 
            // Laundry
            // 
            this.Laundry.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.WhatsApp_Image_2023_09_20_at_23_57_31;
            this.Laundry.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Laundry.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Laundry.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Laundry.Location = new System.Drawing.Point(329, 80);
            this.Laundry.Name = "Laundry";
            this.Laundry.Size = new System.Drawing.Size(500, 300);
            this.Laundry.TabIndex = 12;
            this.Laundry.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.WhatsApp_Image_2023_09_20_at_20_21_39;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(24, 67);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(231, 202);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // services_page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1904, 1041);
            this.Controls.Add(this.foood);
            this.Controls.Add(this.CleaningServices);
            this.Controls.Add(this.Laundry);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.panel1);
            this.Name = "services_page";
            this.Text = "services_page";
            this.Load += new System.EventHandler(this.services_page_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button ContactUs;
        private System.Windows.Forms.Button Services;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Food;
        private System.Windows.Forms.Button roooms;
        private System.Windows.Forms.Button Home;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button Laundry;
        private System.Windows.Forms.Button CleaningServices;
        private System.Windows.Forms.Button foood;
    }
}