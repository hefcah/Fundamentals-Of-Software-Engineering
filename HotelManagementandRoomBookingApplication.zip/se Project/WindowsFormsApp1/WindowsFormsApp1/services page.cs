﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class services_page : Form
    {
        public services_page()
        {
            InitializeComponent();
        }

        private void Home_Click(object sender, EventArgs e)
        {

            Home_Page f = new Home_Page();
            f.Show();
            this.Hide();
        }

        private void roooms_Click(object sender, EventArgs e)
        {
            ROOMS f = new ROOMS();
            f.Show();
            this.Hide();
        }

        private void Food_Click(object sender, EventArgs e)
        {
            Food f = new Food();
            f.Show();
            this.Hide();
        }

        private void Services_Click(object sender, EventArgs e)
        {

        }

        private void ContactUs_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void services_page_Load(object sender, EventArgs e)
        {

        }
    }
}
