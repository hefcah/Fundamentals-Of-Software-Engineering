﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        void file_update(string t, string num, string contact, string email, string start, string end)
        {
            try
            {
                bool done = true;
                string file_name = t + ".txt";

                if (!File.Exists(file_name))
                {
                    using (FileStream fs = File.Create(file_name)) { }
                }

                string[] lines = File.ReadAllLines(file_name);
                //update if rome num available 
                for (int i = 0; i < lines.Length; i += 6)
                {
                    if (lines[i] == num)
                    {
                        lines[i + 1] = contact;
                        lines[i + 2] = email;
                        lines[i + 3] = start;
                        lines[i + 4] = end;
                        done = false;
                        File.WriteAllLines(file_name, lines);
                        break;
                    }
                }
                //if room num not available 
                if (done)
                {
                    File.AppendAllText(file_name, num + Environment.NewLine);
                    File.AppendAllText(file_name, contact + Environment.NewLine);
                    File.AppendAllText(file_name, email + Environment.NewLine);
                    File.AppendAllText(file_name, start + Environment.NewLine);
                    File.AppendAllText(file_name, end + Environment.NewLine);
                    File.AppendAllText(file_name, Environment.NewLine);
                }

            }
            catch (Exception)
            {

            }
        }

        int room_num = 0;
        string type = "";
        string contact = "";
        string email = "";
        string start = "";
        string end = "";
        public Form2(int num, string Type)
        {
            InitializeComponent();
            room_num = num;
            type = Type;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (contact != "" && email != "" && start != "" && end != "")
            {
                string num = room_num.ToString();
                file_update(type, num, contact, email, start, end);
                this.Hide();
            }
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            contact = textBox1.Text;
        }

        private void textBox4_TextChanged_1(object sender, EventArgs e)
        {
            email = textBox4.Text;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            start = textBox3.Text;
        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {
            end = textBox2.Text;
        }
    }
}
