﻿namespace WindowsFormsApp1
{
    partial class Home_Page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.ContactUs = new System.Windows.Forms.Button();
            this.Services = new System.Windows.Forms.Button();
            this.Food = new System.Windows.Forms.Button();
            this.Home = new System.Windows.Forms.Button();
            this.Rooms = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AccessibleRole = System.Windows.Forms.AccessibleRole.Application;
            this.panel1.BackColor = System.Drawing.SystemColors.Window;
            this.panel1.Controls.Add(this.ContactUs);
            this.panel1.Controls.Add(this.Services);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.Food);
            this.panel1.Controls.Add(this.Home);
            this.panel1.Controls.Add(this.Rooms);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(285, 1041);
            this.panel1.TabIndex = 0;
            // 
            // ContactUs
            // 
            this.ContactUs.BackColor = System.Drawing.SystemColors.Window;
            this.ContactUs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ContactUs.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ContactUs.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ContactUs.Location = new System.Drawing.Point(46, 770);
            this.ContactUs.Name = "ContactUs";
            this.ContactUs.Size = new System.Drawing.Size(186, 86);
            this.ContactUs.TabIndex = 5;
            this.ContactUs.Text = "Contact Us";
            this.ContactUs.UseVisualStyleBackColor = false;
            // 
            // Services
            // 
            this.Services.BackColor = System.Drawing.SystemColors.Window;
            this.Services.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Services.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Services.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Services.Location = new System.Drawing.Point(46, 665);
            this.Services.Name = "Services";
            this.Services.Size = new System.Drawing.Size(186, 86);
            this.Services.TabIndex = 4;
            this.Services.Text = "Services";
            this.Services.UseVisualStyleBackColor = false;
            this.Services.Click += new System.EventHandler(this.button4_Click);
            // 
            // Food
            // 
            this.Food.BackColor = System.Drawing.SystemColors.Window;
            this.Food.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Food.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Food.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Food.Location = new System.Drawing.Point(46, 560);
            this.Food.Name = "Food";
            this.Food.Size = new System.Drawing.Size(186, 86);
            this.Food.TabIndex = 3;
            this.Food.Text = "Food";
            this.Food.UseVisualStyleBackColor = false;
            this.Food.Click += new System.EventHandler(this.button3_Click);
            // 
            // Home
            // 
            this.Home.BackColor = System.Drawing.SystemColors.Window;
            this.Home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Home.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Home.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Home.Location = new System.Drawing.Point(46, 344);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(186, 86);
            this.Home.TabIndex = 1;
            this.Home.Text = "Home";
            this.Home.UseVisualStyleBackColor = false;
            this.Home.Click += new System.EventHandler(this.button1_Click);
            // 
            // Rooms
            // 
            this.Rooms.BackColor = System.Drawing.SystemColors.Window;
            this.Rooms.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Rooms.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rooms.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Rooms.Location = new System.Drawing.Point(46, 453);
            this.Rooms.Name = "Rooms";
            this.Rooms.Size = new System.Drawing.Size(186, 86);
            this.Rooms.TabIndex = 2;
            this.Rooms.Text = "Rooms";
            this.Rooms.UseVisualStyleBackColor = false;
            this.Rooms.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(1050, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 57);
            this.label1.TabIndex = 2;
            this.label1.Text = "HOME";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Window;
            this.label2.Location = new System.Drawing.Point(964, 639);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 31);
            this.label2.TabIndex = 4;
            this.label2.Text = "ROOMS";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(1581, 639);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 31);
            this.label3.TabIndex = 5;
            this.label3.Text = "FOOD";
            // 
            // button6
            // 
            this.button6.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.FOOOOF;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.Location = new System.Drawing.Point(1152, 304);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(571, 381);
            this.button6.TabIndex = 3;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.hotell;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.Location = new System.Drawing.Point(512, 301);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(594, 390);
            this.button5.TabIndex = 1;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.WhatsApp_Image_2023_09_20_at_20_21_39;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(24, 67);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(231, 202);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Home_Page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1904, 1041);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.panel1);
            this.Name = "Home_Page";
            this.Text = "Home_Page";
            this.Load += new System.EventHandler(this.Home_Page_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Services;
        private System.Windows.Forms.Button Food;
        private System.Windows.Forms.Button Rooms;
        private System.Windows.Forms.Button Home;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button ContactUs;
    }
}