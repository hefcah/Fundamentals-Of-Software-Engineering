﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsApp1
{
    public partial class Food : Form
    {
        public Food()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Home_Click(object sender, EventArgs e)
        {
            Home_Page f = new Home_Page();
            f.Show();
            this.Hide();
        }

        private void roooms_Click(object sender, EventArgs e)
        {
            ROOMS f = new ROOMS();
            f.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Food f = new Food();
            f.Show();
            this.Hide();
        }

        private void Services_Click(object sender, EventArgs e)
        {
            services_page f = new services_page();
            f.Show();
            this.Hide();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Food_Load(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int bill = 0;

            if(checkBox1.Checked)
            {
                bill += 100;
                File.AppendAllText("Order.txt", "Daal" + Environment.NewLine);
            }

            if (checkBox2.Checked)
            {
                bill += 200;
                File.AppendAllText("Order.txt", "Biryani" + Environment.NewLine);
            }

            if (checkBox3.Checked)
            {
                bill += 10;
                File.AppendAllText("Order.txt", "Naan" + Environment.NewLine);
            }

            if (checkBox4.Checked)
            {
                bill += 1500;
                File.AppendAllText("Order.txt", "Pizza" + Environment.NewLine);
            }

            if (checkBox5.Checked)
            {
                bill += 250;
                File.AppendAllText("Order.txt", "Burger" + Environment.NewLine);
            }

            if (checkBox6.Checked)
            {
                bill += 150;
                File.AppendAllText("Order.txt", "Fries" + Environment.NewLine);
            }

            if (checkBox7.Checked)
            {
                bill += 350;
                File.AppendAllText("Order.txt", "Mint Margarita" + Environment.NewLine);
            }

            if (checkBox8.Checked)
            {
                bill += 100;
                File.AppendAllText("Order.txt", "Fresh Lime" + Environment.NewLine);
            }

            if (checkBox9.Checked)
            {
                bill += 50;
                File.AppendAllText("Order.txt", "Water" + Environment.NewLine);
            }

            if (checkBox10.Checked)
            {
                bill += 100;
                File.AppendAllText("Order.txt", "Ice Cream" + Environment.NewLine);
            }

            if (checkBox11.Checked)
            {
                bill += 200;
                File.AppendAllText("Order.txt", "Kheer" + Environment.NewLine);
            }
        }
    }
}
