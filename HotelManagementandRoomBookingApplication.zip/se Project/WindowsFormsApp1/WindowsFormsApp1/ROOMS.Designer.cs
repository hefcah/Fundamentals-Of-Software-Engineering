﻿namespace WindowsFormsApp1
{
    partial class ROOMS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.ContactUs = new System.Windows.Forms.Button();
            this.Services = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Food = new System.Windows.Forms.Button();
            this.Home = new System.Windows.Forms.Button();
            this.roooms = new System.Windows.Forms.Button();
            this.SingleBedroom = new System.Windows.Forms.Button();
            this.CustomBedroom = new System.Windows.Forms.Button();
            this.DoubleBedroom = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AccessibleRole = System.Windows.Forms.AccessibleRole.Application;
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.ContactUs);
            this.panel1.Controls.Add(this.Services);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.Food);
            this.panel1.Controls.Add(this.Home);
            this.panel1.Controls.Add(this.roooms);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(285, 857);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // ContactUs
            // 
            this.ContactUs.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ContactUs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ContactUs.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ContactUs.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ContactUs.ForeColor = System.Drawing.SystemColors.Window;
            this.ContactUs.Location = new System.Drawing.Point(46, 767);
            this.ContactUs.Name = "ContactUs";
            this.ContactUs.Size = new System.Drawing.Size(186, 86);
            this.ContactUs.TabIndex = 5;
            this.ContactUs.Text = "Contact Us";
            this.ContactUs.UseVisualStyleBackColor = false;
            // 
            // Services
            // 
            this.Services.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Services.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Services.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Services.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Services.ForeColor = System.Drawing.SystemColors.Window;
            this.Services.Location = new System.Drawing.Point(46, 665);
            this.Services.Name = "Services";
            this.Services.Size = new System.Drawing.Size(186, 86);
            this.Services.TabIndex = 4;
            this.Services.Text = "Services";
            this.Services.UseVisualStyleBackColor = false;
            this.Services.Click += new System.EventHandler(this.button4_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.WhatsApp_Image_2023_09_20_at_20_21_39;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(24, 67);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(231, 202);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Food
            // 
            this.Food.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Food.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Food.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Food.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Food.ForeColor = System.Drawing.SystemColors.Window;
            this.Food.Location = new System.Drawing.Point(46, 560);
            this.Food.Name = "Food";
            this.Food.Size = new System.Drawing.Size(186, 86);
            this.Food.TabIndex = 3;
            this.Food.Text = "Food";
            this.Food.UseVisualStyleBackColor = false;
            this.Food.Click += new System.EventHandler(this.button3_Click);
            // 
            // Home
            // 
            this.Home.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Home.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Home.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Home.ForeColor = System.Drawing.SystemColors.Window;
            this.Home.Location = new System.Drawing.Point(46, 344);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(186, 86);
            this.Home.TabIndex = 1;
            this.Home.Text = "Home";
            this.Home.UseVisualStyleBackColor = false;
            this.Home.Click += new System.EventHandler(this.button1_Click);
            // 
            // roooms
            // 
            this.roooms.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.roooms.Cursor = System.Windows.Forms.Cursors.Hand;
            this.roooms.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.roooms.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roooms.ForeColor = System.Drawing.SystemColors.Window;
            this.roooms.Location = new System.Drawing.Point(46, 453);
            this.roooms.Name = "roooms";
            this.roooms.Size = new System.Drawing.Size(186, 86);
            this.roooms.TabIndex = 2;
            this.roooms.Text = "Rooms";
            this.roooms.UseVisualStyleBackColor = false;
            this.roooms.Click += new System.EventHandler(this.button2_Click);
            // 
            // SingleBedroom
            // 
            this.SingleBedroom.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.SingleBedroom.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SingleBedroom.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.SingleBedroom.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SingleBedroom.ForeColor = System.Drawing.SystemColors.Window;
            this.SingleBedroom.Location = new System.Drawing.Point(812, 274);
            this.SingleBedroom.Name = "SingleBedroom";
            this.SingleBedroom.Size = new System.Drawing.Size(700, 125);
            this.SingleBedroom.TabIndex = 2;
            this.SingleBedroom.Text = "Single Bedroom";
            this.SingleBedroom.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.SingleBedroom.UseVisualStyleBackColor = false;
            this.SingleBedroom.Click += new System.EventHandler(this.SingleBedroom_Click);
            // 
            // CustomBedroom
            // 
            this.CustomBedroom.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.CustomBedroom.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CustomBedroom.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.CustomBedroom.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomBedroom.ForeColor = System.Drawing.SystemColors.Window;
            this.CustomBedroom.Location = new System.Drawing.Point(812, 585);
            this.CustomBedroom.Name = "CustomBedroom";
            this.CustomBedroom.Size = new System.Drawing.Size(700, 125);
            this.CustomBedroom.TabIndex = 3;
            this.CustomBedroom.Text = "Triple Bedroom";
            this.CustomBedroom.UseVisualStyleBackColor = false;
            this.CustomBedroom.Click += new System.EventHandler(this.CustomBedroom_Click);
            // 
            // DoubleBedroom
            // 
            this.DoubleBedroom.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DoubleBedroom.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DoubleBedroom.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.DoubleBedroom.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DoubleBedroom.ForeColor = System.Drawing.SystemColors.Window;
            this.DoubleBedroom.Location = new System.Drawing.Point(812, 432);
            this.DoubleBedroom.Name = "DoubleBedroom";
            this.DoubleBedroom.Size = new System.Drawing.Size(700, 125);
            this.DoubleBedroom.TabIndex = 4;
            this.DoubleBedroom.Text = "Double Bedroom";
            this.DoubleBedroom.UseVisualStyleBackColor = false;
            this.DoubleBedroom.Click += new System.EventHandler(this.DoubleBedroom_Click);
            // 
            // ROOMS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = global::WindowsFormsApp1.Properties.Resources._1bdroom;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1824, 857);
            this.Controls.Add(this.DoubleBedroom);
            this.Controls.Add(this.CustomBedroom);
            this.Controls.Add(this.SingleBedroom);
            this.Controls.Add(this.panel1);
            this.Name = "ROOMS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ROOMS";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Services;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Food;
        private System.Windows.Forms.Button Home;
        private System.Windows.Forms.Button roooms;
        private System.Windows.Forms.Button SingleBedroom;
        private System.Windows.Forms.Button CustomBedroom;
        private System.Windows.Forms.Button DoubleBedroom;
        private System.Windows.Forms.Button ContactUs;
    }
}